#ifndef NOVP_H
#define NOVP_H


class noVP
{
    public:
        noVP();
        virtual ~noVP();

        noVP* getFilhoEsq();
        noVP* getFilhoDir();
        bool getCor();
        int getValor();

        void setFilhoEsq(noVP* no);
        void setFilhoDir(noVP* no);
        void setCor(bool cor);
        void setValor(int value);

    protected:

    private:
        bool cor;
        int valor;
        noVP* filhoEsq;
        noVP* filhoDir;
};

#endif // NOVP_H
