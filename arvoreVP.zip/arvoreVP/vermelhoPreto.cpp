#include "vermelhoPreto.h"


vermelhoPreto::vermelhoPreto()
{
    raiz = NULL;
}

vermelhoPreto::~vermelhoPreto()
{
    //dtor
}
noVP* vermelhoPreto::getRaiz(){
    return raiz;
}
void vermelhoPreto::insere(int valor)
{
    noVP* no = new noVP();
    no->setValor(valor);
    no->setCor(1);

    noVP* aux = new noVP();
    aux = raiz;

    if (raiz == NULL) {
        raiz = no;
    }
    else {
        while (true){
            if (no->getValor() >= aux->getValor()){
                if (aux->getFilhoDir()==NULL){
                    aux->setFilhoDir(no);
                    break;
                }
                else {
                    aux = aux->getFilhoDir();
                }
            }
            else {
                if (aux->getFilhoEsq()==NULL){
                    aux->setFilhoEsq(no);
                    break;
                }
                else {
                    aux = aux->getFilhoEsq();
                }
            }
        }
    }
}
void vermelhoPreto::imprimeArvore(noVP* no){
    cout << "No: "<< no->getValor() << "-cor:" << no->getCor() << endl;

    if (no->getFilhoEsq() == NULL){
        cout << "FilhoEsq: "<< "Nao Possui" << endl;
    }
    else {
        cout << "FilhoEsq: "<< no->getFilhoEsq()->getValor() << "-cor:" << no->getFilhoEsq()->getCor() << endl;
    }

    if (no->getFilhoDir() == NULL){
        cout << "FilhoEsq: "<< "Nao Possui" << endl;
    }
    else {
        cout << "FilhoDir: "<< no->getFilhoDir()->getValor() << "-cor:" << no->getFilhoDir()->getCor() << endl;
    }

    cout << endl <<"-----------------------------------------------------------" << endl;

    if (no->getFilhoEsq()!=NULL){
        imprimeArvore(no->getFilhoEsq());
    }
    if (no->getFilhoDir()!=NULL){
        imprimeArvore(no->getFilhoDir());
    }
}
