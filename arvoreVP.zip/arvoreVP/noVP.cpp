#include "noVP.h"

noVP::noVP()
{
    cor = 1;
}

noVP::~noVP()
{
    //dtor
}
noVP* noVP :: getFilhoEsq(){
    return filhoEsq;
}
noVP* noVP::getFilhoDir()
{
    return filhoDir;
}

bool noVP::getCor()
{
    return cor;
}

int noVP::getValor()
{
    return valor;
}

void noVP::setFilhoEsq(noVP* no)
{
    filhoEsq = no;
}

void noVP::setFilhoDir(noVP* no)
{
    filhoDir = no;
}

void noVP::setCor(bool cor)
{
    cor = cor;
}

void noVP::setValor(int value)
{
    valor = value;
}
