#ifndef VERMELHOPRETO_H
#define VERMELHOPRETO_H
#include "noVP.h"
#include <iostream>
using namespace std;


class vermelhoPreto
{
    public:
        vermelhoPreto();
        virtual ~vermelhoPreto();
        void insere(int valor);
        void imprimeArvore(noVP* no);
        noVP* getRaiz();
    protected:

    private:
        noVP* raiz;


};

#endif // VERMELHOPRETO_H
