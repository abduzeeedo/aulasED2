#include <iostream>
#include "vermelhoPreto.h"

using namespace std;

int main()
{
    //cout << "Hello world!" << endl;

    vermelhoPreto* arvore = new vermelhoPreto();

    arvore->insere(20);
    arvore->insere(10);
    arvore->insere(30);
    arvore->insere(40);
    arvore->insere(5);
    arvore->insere(15);
    arvore->insere(25);
    arvore->insere(35);

    arvore->imprimeArvore(arvore->getRaiz());
    return 0;
}
