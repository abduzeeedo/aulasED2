#ifndef NO_H
#define NO_H
#include <iostream>


class no
{
    public:
        no();
        virtual ~no();

    protected:

    private:
};

#endif // NO_H
