#ifndef AVL_H
#define AVL_H
#include "node.h"
#include <iostream>
#include <stdlib.h>

class avl
{
    public:
        avl();
        virtual ~avl();

        node* raiz;

        void inserirAVL(int pla);

        void removerAVL (int pla);

        node* buscaAVL(int pla);
        node* rotacaoRR(node* pla);
        node* rotacaoLL(node* pla);
        node* rotacaoRL(node* pla);
        node* rotacaoLR(node* pla);

    protected:

    private:
};

#endif // AVL_H
