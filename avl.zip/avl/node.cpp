#include "node.h"

node::node()
{
    //ctor
}

node::~node()
{
    //dtor
}
void node::setValor(int pla){
    valor = pla;
}
int node::getValor(){
    return valor;
}
void node::setFB(int pla){
    valor = pla;
}
int node::getFB(){
    return valor;
}
void node::setEsq(node* pla){
    esq = pla;
}
node* node::getEsq(){
    return esq;
}
void node::setDir(node* pla){
    dir = pla;
}
node* node::getDir(){
    return dir;
}
void node::setPai(node* pla){
    pai = pla;
}
node* node::getPai(){
    return pai;
}
