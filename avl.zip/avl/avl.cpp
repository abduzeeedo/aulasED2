#include "avl.h"


avl::avl()
{
    raiz = NULL;
}

avl::~avl()
{
    //dtor
}
node* avl::rotacaoRR(node* pla){
    node* x = pla->getDir();
    pla->setDir(x->getEsq());
    x->setEsq(pla);
    return x;
}
