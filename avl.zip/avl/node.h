#ifndef NODE_H
#define NODE_H


class node
{
    public:
        node();
        virtual ~node();
        void setValor(int pla);
        int getValor();
        void setFB(int pla);
        int getFB();
        void setEsq(node* pla);
        node* getEsq();
        void setDir(node* pla);
        node* getDir();
        void setPai(node* pla);
        node* getPai();


    protected:

    private:
        int valor;
        int fb;
        node* esq;
        node* dir;
        node* pai;
};

#endif // NODE_H
